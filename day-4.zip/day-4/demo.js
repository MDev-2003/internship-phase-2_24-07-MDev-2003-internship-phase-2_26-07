function b1(){
    alert("hola, como estas??")
}
function b2(){
    if(confirm("You wanna continue??"))
    {
        alert("done well");
    }
    else{
        alert("U can go! 🙂");
    }
}
function b3(){
    let fname=prompt("Enter your firstname :");
    let lname=prompt("Enter your lastname :");
    alert(fname + " " + lname);
}